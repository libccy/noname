window.noname_update={
    version:'1.8.3.0',
    changeLog:[
        '风火林山联机',
        'bug修复'
    ]
}
