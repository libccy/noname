window.noname_update={
    version:'1.8.3.3',
    changeLog:[
        '修复重连问题',
        '修复无法进入游戏的问题'
    ]
}
