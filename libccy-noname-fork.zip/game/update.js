window.noname_update={
	version:'1.10.2.1',
	update:'1.10.2',
	changeLog:[
		'整合@rintim @mengxinzxz @lieren2023 @PZ157 @Tipx-L @kuangshen04 @nonameShijian @copcap的Pull Request',
		'新武将：界钟繇、武陆逊、界文聘、许靖、孟优、陈式、费曜、孙礼、夏侯楙、OL陆郁生、☆周不疑、',
		'音效优化：增加不同属性伤害的不同音效',
		'技能优化：神典韦、手杀南华老仙等',
		'机制更新: 属性【杀】机制完善优化等',
		'界面更新: 优化自带代码编辑器；启动页增加新样式；武将资料页美化等',
		'其他技能修改与bug修复',
	],
	files:[
		'card/yingbian.js',
		'character/extra.js',
		'character/huicui.js',
		'character/jsrg.js',
		'character/shenhua.js',
		'character/shiji.js',
		'character/xianding.js',
		'character/yijiang.js',
		'game/game.js',
		'mode/doudizhu.js',
		'mode/guozhan.js',
		'mode/identity.js',
		'mode/single.js',
	]
};
