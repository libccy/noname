character.xswd={
	character:{
		
	},
}
